
//Determina se o numero é perfeito
int isPerfeito(int);

//Determina se o numero é primo
int isPrimo(int);